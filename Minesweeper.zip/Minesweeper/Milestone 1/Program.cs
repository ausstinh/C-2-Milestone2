﻿using ChessBoardModel;
using System;

namespace Milestone1
{
    class Program
    {
        static Board myBoard = new Board(12);
        private static bool isOver = false;

        static void Main(string[] args)
        {
            //blank board
            printBoard(myBoard);
            //set up bombs
            myBoard.SetupLiveNeightbors(myBoard);
            //set up neighbors
            myBoard.CalculateLiveNeighbors(myBoard);

            //play game
            while (!isOver)
            {
                //ask for position
                SetCurrentCell();
                //updated board
                printBoard(myBoard);
                //record number of turns
                myBoard.NumberOfTurns++;
                Console.WriteLine(myBoard.NumberOfTurns);
                //check if you win
                CheckWin(myBoard);
            }
            Console.ReadLine();



        }
        static public void printBoard(Board myBoard)
        {
            Console.WriteLine("+ 0 + 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10+ 11+");
            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int j = 0; j < myBoard.Size; j++)
                {

                    if (myBoard.theGrid[i, j].Live && myBoard.theGrid[i, j].IsVisited)
                    {
                        Console.Write("| * ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 0)
                    {
                        Console.Write("| 0 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 1)
                    {
                        Console.Write("| 1 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 2)
                    {
                        Console.Write("| 2 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 3)
                    {
                        Console.Write("| 3 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 4)
                    {
                        Console.Write("| 4 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 5)
                    {
                        Console.Write("| 5 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 6)
                    {
                        Console.Write("| 6 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 7)
                    {
                        Console.Write("| 7 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 8)
                    {
                        Console.Write("| 8 ");
                    }
                    else if (myBoard.theGrid[i, j].IsVisited && myBoard.theGrid[i, j].LiveNeighbors == 9)
                    {
                        Console.Write("| 9 ");
                    }
                    else if (!myBoard.theGrid[i, j].IsVisited)
                    {
                        Console.Write("| ? ");
                    }
                    else
                    {
                        Console.Write("+---");
                    }
                }

                Console.Write("|" + i);
                Console.WriteLine();

            }
            Console.WriteLine("+---+---+---+---+---+---+---+---+---+---+---+---+");
            Console.WriteLine("=================================================");
        }
        static public Cell SetCurrentCell()
        {
            Console.Out.Write("Enter your current row number: ");
            string r = Console.ReadLine();
            int currentRow;
            if (int.TryParse(r, out currentRow))
            {
                currentRow = int.Parse(r);
            }
            else
            {
                Console.WriteLine("Not a number, try again please");
                Console.Out.Write("Enter your current row number: ");
                currentRow = int.Parse(Console.ReadLine());
            }
            Console.Out.Write("Enter your current column number: ");
            string c = Console.ReadLine();
            int currentCol;
            if (int.TryParse(r, out currentCol))
            {
                currentCol = int.Parse(r);
            }
            else
            {
                Console.Out.Write("Not a number, try again please");
                currentCol = int.Parse(Console.ReadLine());
            }
            if (myBoard.IsSafe(currentRow, currentCol))
            {
                if (myBoard.theGrid[currentRow, currentCol].IsVisited)
                {
                    myBoard.NumberOfTurns--;
                }
                myBoard.theGrid[currentRow, currentCol].IsVisited = true;

                if (myBoard.theGrid[currentRow, currentCol].Live)
                {
                    Console.WriteLine("you landed on a bomb! game over");
                    isOver = true;
                }
            }
            if (!myBoard.IsSafe(currentRow, currentCol))
            {
                Console.WriteLine("Enter a number inside the bounds");
            }
            return myBoard.theGrid[currentRow, currentCol];
        }
        static public void CheckWin(Board myBoard)
        {
            double bombs = myBoard.Size * myBoard.Size * myBoard.Difficulty;
            int NumberOfBombs = Convert.ToInt32(bombs);
            double EmptyCells = (myBoard.Size * myBoard.Size) - NumberOfBombs;
            if (EmptyCells == myBoard.NumberOfTurns)
            {
                isOver = true;
                Console.WriteLine("You win the game!");
            }
        }
    }
}
