﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChessBoardModel
{
    public class Board
    {
        public int Size { get; set; }
        public Cell[,] theGrid { get; set; }
        public double Difficulty { get; set; }
        public int NumberOfTurns { get; set; }
        public Board(int s)
        {
            NumberOfTurns = 0;
            Size = s;
            theGrid = new Cell[Size, Size];
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    theGrid[i, j] = new Cell(i, j);
                }
            }
        }
        public bool IsSafe(int x, int y)
        {
            if (x < 0 || x >= Size || y < 0 || y >= Size)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public void SetupLiveNeightbors(Board myBoard)
        {   //get percentage of cells to become bombs
            Difficulty = .30;
            double bomb = Size * Size * Difficulty;
            int NumberOfBombs = Convert.ToInt32(bomb);
            for (int b = 0; b < bomb; b++)
            {
                //set random number of cells to bombs
                Random rand = new Random();
                int row = rand.Next(0, Size);
                int col = rand.Next(0, Size);
                //make new position is a bomb
                myBoard.theGrid[row, col].Live = true;
            }

        }
        public void CalculateLiveNeighbors(Board myBoard)
        {
            Random rand = new Random();
            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int j = 0; j < myBoard.Size; j++)
                {

                    // look up one square
                    if (IsSafe(i - 1, j))
                    {
                        if (myBoard.theGrid[i - 1, j - 0].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    // look down one
                    if (IsSafe(i + 1, j - 0))
                    {
                        if (myBoard.theGrid[i + 1, j - 0].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look left one
                    if (IsSafe(i - 0, j - 1))
                    {
                        if (myBoard.theGrid[i - 0, j - 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look right one
                    if (IsSafe(i - 0, j + 1))
                    {
                        if (myBoard.theGrid[i - 0, j + 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look up and left
                    if (IsSafe(i - 1, j - 1))
                    {
                        if (myBoard.theGrid[i - 1, j - 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look up and right
                    if (IsSafe(i - 1, j + 1))
                    {
                        if (myBoard.theGrid[i - 1, j + 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look down and right
                    if (IsSafe(i + 1, j + 1))
                    {
                        if (myBoard.theGrid[i + 1, j + 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    //look down and left
                    if (IsSafe(i + 1, j - 1))
                    {
                        if (myBoard.theGrid[i + 1, j - 1].Live)
                            myBoard.theGrid[i, j].LiveNeighbors++;
                    }
                    if (IsSafe(i, j))
                    {
                        if (theGrid[i, j].Live)
                            myBoard.theGrid[i, j].LiveNeighbors = 9;
                    }


                }
            }

        }



    }
}
